const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'keybank-secret-change-me-in-production-2026';
const DATA_DIR = path.join(__dirname, 'data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const TXNS_FILE = path.join(DATA_DIR, 'transactions.json');
const CHATS_FILE = path.join(DATA_DIR, 'chats.json');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(USERS_FILE)) fs.writeFileSync(USERS_FILE, '[]');
if (!fs.existsSync(TXNS_FILE)) fs.writeFileSync(TXNS_FILE, '[]');
if (!fs.existsSync(CHATS_FILE)) fs.writeFileSync(CHATS_FILE, '[]');

app.use(cors());
app.use(express.json({ limit: '2mb' }));
app.use(express.static(path.join(__dirname, 'public')));

function read(file) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return []; }
}
function write(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function genAccount() {
  return 'KB' + Date.now().toString().slice(-8) + Math.floor(Math.random() * 900 + 100);
}

function auth(req, res, next) {
  const h = req.headers.authorization;
  if (!h || !h.startsWith('Bearer ')) return res.status(401).json({ error: 'Unauthorized' });
  try {
    req.user = jwt.verify(h.split(' ')[1], JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error: 'Invalid token' });
  }
}

function adminOnly(req, res, next) {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Admin only' });
  next();
}

// Ensure default admin
(function ensureAdmin() {
  const users = read(USERS_FILE);
  if (!users.find(u => u.role === 'admin')) {
    users.push({
      id: uuidv4(),
      name: 'System Admin',
      email: 'admin@keybank.com',
      passwordHash: bcrypt.hashSync('Admin@123', 10),
      accountNumber: 'KB0000000001',
      balance: 1000000,
      role: 'admin',
      avatar: null,
      createdAt: new Date().toISOString()
    });
    write(USERS_FILE, users);
    console.log('Admin created: admin@keybank.com / Admin@123');
  }
})();

// ========== AUTH ==========
app.post('/api/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password) return res.status(400).json({ error: 'Name, email and password required' });
    if (password.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters' });
    const users = read(USERS_FILE);
    if (users.find(u => u.email.toLowerCase() === email.toLowerCase())) {
      return res.status(400).json({ error: 'Email already registered' });
    }
    const user = {
      id: uuidv4(),
      name: name.trim(),
      email: email.toLowerCase().trim(),
      passwordHash: await bcrypt.hash(password, 10),
      accountNumber: genAccount(),
      balance: 0,
      role: 'user',
      avatar: null,
      createdAt: new Date().toISOString()
    };
    users.push(user);
    write(USERS_FILE, users);
    res.status(201).json({ message: 'Account created', accountNumber: user.accountNumber, name: user.name });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password required' });
    const users = read(USERS_FILE);
    const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }
    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role, accountNumber: user.accountNumber, name: user.name },
      JWT_SECRET,
      { expiresIn: '7d' }
    );
    res.json({
      token,
      user: { id: user.id, name: user.name, email: user.email, accountNumber: user.accountNumber, balance: user.balance, role: user.role, avatar: user.avatar }
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/me', auth, (req, res) => {
  const user = read(USERS_FILE).find(u => u.id === req.user.id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json({ id: user.id, name: user.name, email: user.email, accountNumber: user.accountNumber, balance: user.balance, role: user.role, avatar: user.avatar });
});

// ========== TRANSACTIONS ==========
app.get('/api/transactions', auth, (req, res) => {
  let txns = read(TXNS_FILE);
  if (req.user.role !== 'admin') txns = txns.filter(t => t.accountNumber === req.user.accountNumber);
  txns.sort((a, b) => new Date(b.date) - new Date(a.date));
  res.json(txns);
});

app.post('/api/transfer', auth, (req, res) => {
  try {
    const { toAccount, amount, description } = req.body;
    const num = parseFloat(amount);
    if (!toAccount || isNaN(num) || num <= 0) return res.status(400).json({ error: 'Valid account and amount required' });
    const users = read(USERS_FILE);
    const from = users.find(u => u.id === req.user.id);
    const to = users.find(u => u.accountNumber === toAccount);
    if (!to) return res.status(404).json({ error: 'Recipient account not found' });
    if (to.accountNumber === from.accountNumber) return res.status(400).json({ error: 'Cannot transfer to yourself' });
    if (from.balance < num) return res.status(400).json({ error: 'Insufficient balance' });
    from.balance = +(from.balance - num).toFixed(2);
    to.balance = +(to.balance + num).toFixed(2);
    write(USERS_FILE, users);
    const now = new Date().toISOString();
    const txns = read(TXNS_FILE);
    const debit = { id: uuidv4(), accountNumber: from.accountNumber, userName: from.name, type: 'debit', amount: num, description: description || `Transfer to ${to.accountNumber}`, date: now, createdBy: from.email };
    const credit = { id: uuidv4(), accountNumber: to.accountNumber, userName: to.name, type: 'credit', amount: num, description: description || `Transfer from ${from.accountNumber}`, date: now, createdBy: from.email };
    txns.push(debit, credit);
    write(TXNS_FILE, txns);
    res.json({ message: 'Transfer successful', newBalance: from.balance });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error' });
  }
});

// ========== ADMIN ==========
app.get('/api/admin/users', auth, adminOnly, (req, res) => {
  const users = read(USERS_FILE).map(u => ({
    id: u.id, name: u.name, email: u.email, accountNumber: u.accountNumber, balance: u.balance, role: u.role, createdAt: u.createdAt
  }));
  res.json(users);
});

app.post('/api/admin/transactions', auth, adminOnly, (req, res) => {
  try {
    const { accountNumber, type, amount, description } = req.body;
    if (!accountNumber || !['credit', 'debit'].includes(type)) return res.status(400).json({ error: 'Invalid data' });
    const num = parseFloat(amount);
    if (isNaN(num) || num <= 0) return res.status(400).json({ error: 'Positive amount required' });
    const users = read(USERS_FILE);
    const user = users.find(u => u.accountNumber === accountNumber);
    if (!user) return res.status(404).json({ error: 'Account not found' });
    if (type === 'debit' && user.balance < num) return res.status(400).json({ error: 'Insufficient balance' });
    user.balance = type === 'credit' ? +(user.balance + num).toFixed(2) : +(user.balance - num).toFixed(2);
    write(USERS_FILE, users);
    const txn = {
      id: uuidv4(), accountNumber, userName: user.name, type, amount: num,
      description: description || (type === 'credit' ? 'Deposit' : 'Withdrawal'),
      date: new Date().toISOString(), createdBy: req.user.email
    };
    const txns = read(TXNS_FILE);
    txns.push(txn);
    write(TXNS_FILE, txns);
    res.status(201).json({ message: 'Transaction added', newBalance: user.balance, transaction: txn });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error' });
  }
});

app.delete('/api/admin/transactions/:id', auth, adminOnly, (req, res) => {
  try {
    const txns = read(TXNS_FILE);
    const idx = txns.findIndex(t => t.id === req.params.id);
    if (idx === -1) return res.status(404).json({ error: 'Not found' });
    const txn = txns[idx];
    const users = read(USERS_FILE);
    const user = users.find(u => u.accountNumber === txn.accountNumber);
    if (user) {
      user.balance = txn.type === 'credit' ? +(user.balance - txn.amount).toFixed(2) : +(user.balance + txn.amount).toFixed(2);
      if (user.balance < 0) user.balance = 0;
      write(USERS_FILE, users);
    }
    txns.splice(idx, 1);
    write(TXNS_FILE, txns);
    res.json({ message: 'Deleted', balance: user ? user.balance : null });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error' });
  }
});

// ========== CHAT ==========
app.get('/api/chats', auth, (req, res) => {
  const chats = read(CHATS_FILE);
  if (req.user.role === 'admin') {
    return res.json(chats.filter(c => c.userId !== req.user.id).sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt)));
  }
  let chat = chats.find(c => c.userId === req.user.id);
  if (!chat) {
    chat = { id: uuidv4(), userId: req.user.id, userName: req.user.name, messages: [], updatedAt: new Date().toISOString() };
    chats.push(chat);
    write(CHATS_FILE, chats);
  }
  res.json(chat);
});

app.post('/api/chats/message', auth, (req, res) => {
  const { text, toUserId } = req.body;
  if (!text || !text.trim()) return res.status(400).json({ error: 'Message required' });
  const chats = read(CHATS_FILE);
  let chat;
  if (req.user.role === 'admin' && toUserId) {
    chat = chats.find(c => c.userId === toUserId);
    if (!chat) return res.status(404).json({ error: 'Chat not found' });
    chat.messages.push({ id: uuidv4(), from: 'admin', text: text.trim(), time: new Date().toISOString() });
  } else {
    chat = chats.find(c => c.userId === req.user.id);
    if (!chat) {
      chat = { id: uuidv4(), userId: req.user.id, userName: req.user.name, messages: [], updatedAt: new Date().toISOString() };
      chats.push(chat);
    }
    chat.messages.push({ id: uuidv4(), from: 'user', text: text.trim(), time: new Date().toISOString() });
  }
  chat.updatedAt = new Date().toISOString();
  write(CHATS_FILE, chats);
  res.json(chat);
});

// Avatar
app.post('/api/avatar', auth, (req, res) => {
  const { avatar } = req.body;
  if (!avatar) return res.status(400).json({ error: 'No avatar' });
  const users = read(USERS_FILE);
  const user = users.find(u => u.id === req.user.id);
  if (!user) return res.status(404).json({ error: 'Not found' });
  user.avatar = avatar;
  write(USERS_FILE, users);
  res.json({ message: 'Saved' });
});


// Edit user (name, email, balance, password)
app.put('/api/admin/users/:id', auth, adminOnly, (req, res) => {
  try {
    const { name, email, balance, password } = req.body;
    const users = read(USERS_FILE);
    const user = users.find(u => u.id === req.params.id);
    if (!user) return res.status(404).json({ error: 'User not found' });

    if (name && name.trim()) user.name = name.trim();
    if (email && email.trim()) {
      const emailLower = email.toLowerCase().trim();
      if (users.find(u => u.email === emailLower && u.id !== user.id)) {
        return res.status(400).json({ error: 'Email already in use' });
      }
      user.email = emailLower;
    }
    if (balance !== undefined && balance !== null && balance !== '') {
      const num = parseFloat(balance);
      if (isNaN(num) || num < 0) return res.status(400).json({ error: 'Invalid balance' });
      user.balance = +num.toFixed(2);
    }
    if (password && password.length >= 6) {
      user.passwordHash = bcrypt.hashSync(password, 10);
    }

    write(USERS_FILE, users);
    res.json({
      message: 'Account updated',
      user: {
        id: user.id, name: user.name, email: user.email,
        accountNumber: user.accountNumber, balance: user.balance, role: user.role
      }
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error' });
  }
});


// Edit transaction
app.put('/api/admin/transactions/:id', auth, adminOnly, (req, res) => {
  try {
    const { type, amount, description } = req.body;
    const txns = read(TXNS_FILE);
    const idx = txns.findIndex(t => t.id === req.params.id);
    if (idx === -1) return res.status(404).json({ error: 'Transaction not found' });
    const old = txns[idx];

    const newType = type && ['credit', 'debit'].includes(type) ? type : old.type;
    const newAmount = amount !== undefined && amount !== '' ? parseFloat(amount) : old.amount;
    if (isNaN(newAmount) || newAmount <= 0) return res.status(400).json({ error: 'Invalid amount' });
    const newDesc = description !== undefined ? description : old.description;

    // Reverse old effect on balance
    const users = read(USERS_FILE);
    const user = users.find(u => u.accountNumber === old.accountNumber);
    if (user) {
      if (old.type === 'credit') user.balance = +(user.balance - old.amount).toFixed(2);
      else user.balance = +(user.balance + old.amount).toFixed(2);

      // Apply new effect
      if (newType === 'credit') user.balance = +(user.balance + newAmount).toFixed(2);
      else user.balance = +(user.balance - newAmount).toFixed(2);

      if (user.balance < 0) user.balance = 0;
      write(USERS_FILE, users);
    }

    txns[idx] = {
      ...old,
      type: newType,
      amount: newAmount,
      description: newDesc || (newType === 'credit' ? 'Deposit' : 'Withdrawal')
    };
    write(TXNS_FILE, txns);

    res.json({
      message: 'Transaction updated',
      transaction: txns[idx],
      newBalance: user ? user.balance : null
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error' });
  }
});

// SPA fallback
app.use((req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Key Bank running on port ${PORT}`);
  console.log('Admin: admin@keybank.com / Admin@123');
});
