// ========== API HELPERS ==========
const API = '';  // same origin when served by Express

async function api(path, options = {}) {
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  const token = localStorage.getItem('kb_token');
  if (token) headers['Authorization'] = 'Bearer ' + token;
  const res = await fetch(API + path, { ...options, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

// ========== SETTINGS (theme + currency stay local) ==========
const SETTINGS_KEY = 'kb_settings';
function getSettings() {
  try { return JSON.parse(localStorage.getItem(SETTINGS_KEY)) || { dark: false, currency: 'GBP' }; }
  catch { return { dark: false, currency: 'GBP' }; }
}
function saveSettings(s) { localStorage.setItem(SETTINGS_KEY, JSON.stringify(s)); }

const RATES = { GBP: 1, USD: 1.27, EUR: 1.17 };

let currentUser = null;

function applyTheme(dark) {
  document.body.classList.toggle('dark', dark);
  const t = document.getElementById('theme-toggle');
  if (t) t.textContent = dark ? '☀️' : '🌙';
  const sw = document.getElementById('dark-mode-switch');
  if (sw) sw.checked = dark;
}

function showMessage(id, text, type = 'error') {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = text;
  el.className = 'message show ' + type;
  setTimeout(() => el.classList.remove('show'), 4000);
}

function formatMoney(amount, currency = 'GBP') {
  const symbols = { GBP: '£', USD: '$', EUR: '€' };
  const val = Number(amount) * (RATES[currency] || 1);
  return (symbols[currency] || '£') + val.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function formatDate(iso) {
  const d = new Date(iso);
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) +
    ' ' + d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
}
function formatTime(iso) {
  return new Date(iso).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
}

// ========== RENDER ==========
function renderBalance(user) {
  if (!user) return;
  const settings = getSettings();
  document.getElementById('balance-display').textContent = formatMoney(user.balance, settings.currency || 'GBP');
  document.getElementById('account-number').textContent = user.accountNumber;
  document.getElementById('user-greeting').textContent = 'Hi, ' + (user.name || '').split(' ')[0];
  const converted = document.getElementById('converted-balance');
  const select = document.getElementById('currency-select');
  if (select) select.value = settings.currency || 'GBP';
  if (converted) {
    converted.textContent = settings.currency !== 'GBP' ? 'Base: £ GBP' : '';
  }
  updateAvatarDisplay(user);
}

function updateAvatarDisplay(user) {
  const headerAvatar = document.getElementById('header-avatar');
  const profileAvatar = document.getElementById('profile-avatar');
  if (user.avatar) {
    headerAvatar.src = user.avatar;
    headerAvatar.classList.remove('hidden');
    if (profileAvatar) profileAvatar.src = user.avatar;
  } else {
    headerAvatar.classList.add('hidden');
    if (profileAvatar) {
      profileAvatar.src = 'data:image/svg+xml,' + encodeURIComponent(
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect fill="#0b1c2c" width="100" height="100"/><text x="50" y="60" text-anchor="middle" fill="#c9a84c" font-size="40" font-family="sans-serif">' + (user.name || 'U').charAt(0).toUpperCase() + '</text></svg>'
      );
    }
  }
  const nameEl = document.getElementById('profile-name');
  const emailEl = document.getElementById('profile-email');
  const accEl = document.getElementById('profile-account');
  if (nameEl) nameEl.textContent = user.name;
  if (emailEl) emailEl.textContent = user.email;
  if (accEl) accEl.textContent = user.accountNumber;
}

function renderTransactions(txns) {
  const list = document.getElementById('transactions-list');
  if (!txns || txns.length === 0) {
    list.innerHTML = '<div class="empty-state"><div style="font-size:2rem">📭</div><p>No transactions yet</p></div>';
    return;
  }
  list.innerHTML = txns.map(t => `
    <div class="txn-item">
      <div class="txn-left">
        <div class="txn-icon ${t.type}">${t.type === 'credit' ? '↓' : '↑'}</div>
        <div class="txn-details">
          <h4>${t.description || t.type}</h4>
          <p>${formatDate(t.date)}${currentUser.role === 'admin' ? ' • ' + t.accountNumber : ''}</p>
        </div>
      </div>
      <div class="txn-amount ${t.type}">${t.type === 'credit' ? '+' : '-'}${formatMoney(t.amount)}</div>
    </div>
  `).join('');
}

function renderAdminUsers(users) {
  const list = document.getElementById('users-list');
  if (!list) return;
  window._adminUsers = users || [];
  list.innerHTML = (users || []).map(u => `
    <div class="user-item">
      <div>
        <div class="name">${u.name} ${u.role === 'admin' ? '<span style="color:var(--accent);font-size:0.7rem">(Admin)</span>' : ''}</div>
        <div class="meta">${u.email} • ${u.accountNumber}</div>
      </div>
      <div class="user-item-actions">
        <div style="font-weight:600">${formatMoney(u.balance)}</div>
        <button class="edit-btn" onclick="openEditModal('${u.id}')">Edit</button>
      </div>
    </div>
  `).join('') || '<div class="empty-state"><p>No users yet</p></div>';
}

function renderAdminTransactions(txns) {
  const list = document.getElementById('admin-txns-list');
  if (!list) return;
  window._adminTxns = txns || [];
  if (!txns || txns.length === 0) {
    list.innerHTML = '<div class="empty-state"><p>No transactions</p></div>';
    return;
  }
  list.innerHTML = txns.map(t => `
    <div class="txn-item">
      <div class="txn-left">
        <div class="txn-icon ${t.type}">${t.type === 'credit' ? '↓' : '↑'}</div>
        <div class="txn-details">
          <h4>${t.description || t.type}</h4>
          <p>${t.userName || ''} • ${t.accountNumber} • ${formatDate(t.date)}</p>
        </div>
      </div>
      <div class="txn-actions">
        <span class="txn-amount ${t.type}">${t.type === 'credit' ? '+' : '-'}${formatMoney(t.amount)}</span>
        <button class="edit-btn" onclick="openEditTxnModal('${t.id}')">Edit</button>
        <button class="btn btn-danger" onclick="deleteTransaction('${t.id}')">Delete</button>
      </div>
    </div>
  `).join('');
}

function renderChatMessages(chat) {
  const container = document.getElementById('chat-messages');
  if (!container) return;
  if (!chat || !chat.messages || chat.messages.length === 0) {
    container.innerHTML = '<div class="empty-state" style="padding:30px"><p>No messages yet.<br>Send a message to support.</p></div>';
    return;
  }
  container.innerHTML = chat.messages.map(m => `
    <div class="chat-bubble ${m.from}">
      ${m.text}
      <span class="time">${formatTime(m.time)}</span>
    </div>
  `).join('');
  container.scrollTop = container.scrollHeight;
}

function renderAdminChats(chats) {
  const list = document.getElementById('admin-chats-list');
  if (!list) return;
  if (!chats || chats.length === 0) {
    list.innerHTML = '<div class="empty-state"><p>No customer chats yet</p></div>';
    return;
  }
  list.innerHTML = chats.map(c => {
    const last = c.messages && c.messages[c.messages.length - 1];
    const unread = (c.messages || []).filter(m => m.from === 'user').length;
    return `
      <div class="chat-preview" onclick="openAdminChat('${c.userId}')">
        <div style="display:flex;justify-content:space-between;width:100%">
          <strong>${c.userName}</strong>
          ${unread ? '<span class="unread">' + unread + '</span>' : ''}
        </div>
        <div style="font-size:0.8rem;color:var(--muted);width:100%">
          ${last ? (last.from === 'admin' ? 'You: ' : '') + last.text.slice(0, 50) : 'No messages'}
        </div>
        <div class="admin-reply-box" id="reply-box-${c.userId}" style="display:none">
          <textarea placeholder="Type reply..." id="reply-text-${c.userId}"></textarea>
          <button class="btn btn-primary btn-sm" onclick="event.stopPropagation(); sendAdminReply('${c.userId}')">Send Reply</button>
        </div>
      </div>
    `;
  }).join('');
}

function updateChatBadge(count) {
  const badge = document.getElementById('chat-badge');
  if (!badge) return;
  if (count > 0) {
    badge.textContent = count > 9 ? '9+' : count;
    badge.classList.remove('hidden');
  } else {
    badge.classList.add('hidden');
  }
}

// ========== LOAD DATA ==========
async function refreshAll() {
  try {
    const me = await api('/api/me');
    currentUser = me;
    renderBalance(me);

    const txns = await api('/api/transactions');
    renderTransactions(txns);

    if (me.role === 'admin') {
      document.getElementById('admin-tab-btn').classList.remove('hidden');
      const users = await api('/api/admin/users');
      renderAdminUsers(users);
      renderAdminTransactions(txns);
      const chats = await api('/api/chats');
      renderAdminChats(chats);
      let unread = 0;
      (chats || []).forEach(c => unread += (c.messages || []).filter(m => m.from === 'user').length);
      updateChatBadge(unread);
    } else {
      document.getElementById('admin-tab-btn').classList.add('hidden');
      const chat = await api('/api/chats');
      renderChatMessages(chat);
      const adminMsgs = (chat.messages || []).filter(m => m.from === 'admin').length;
      updateChatBadge(adminMsgs);
    }
  } catch (e) {
    console.error(e);
    if (e.message.includes('Unauthorized') || e.message.includes('Invalid')) {
      logout();
    }
  }
}

function showApp() {
  document.getElementById('auth-screen').classList.add('hidden');
  document.getElementById('app-screen').classList.remove('hidden');
  document.getElementById('chat-widget').classList.remove('hidden');
  document.getElementById('profile-section').style.display = 'block';
  refreshAll();
}

function showAuth() {
  document.getElementById('app-screen').classList.add('hidden');
  document.getElementById('chat-widget').classList.add('hidden');
  document.getElementById('auth-screen').classList.remove('hidden');
}

function logout() {
  localStorage.removeItem('kb_token');
  currentUser = null;
  showAuth();
}

// ========== GLOBAL ACTIONS ==========
async function deleteTransaction(id) {
  try {
    await api('/api/admin/transactions/' + id, { method: 'DELETE' });
    showMessage('admin-message', 'Transaction deleted', 'success');
    refreshAll();
  } catch (e) {
    showMessage('admin-message', e.message, 'error');
  }
}

function openAdminChat(userId) {
  const box = document.getElementById('reply-box-' + userId);
  if (box) box.style.display = box.style.display === 'none' ? 'block' : 'none';
}

async function sendAdminReply(userId) {
  const ta = document.getElementById('reply-text-' + userId);
  if (!ta || !ta.value.trim()) return;
  try {
    await api('/api/chats/message', {
      method: 'POST',
      body: JSON.stringify({ text: ta.value.trim(), toUserId: userId })
    });
    ta.value = '';
    refreshAll();
  } catch (e) {
    alert(e.message);
  }
}


function openEditModal(userId) {
  const users = window._adminUsers || [];
  const u = users.find(x => x.id === userId);
  if (!u) return;
  document.getElementById('edit-user-id').value = u.id;
  document.getElementById('edit-name').value = u.name;
  document.getElementById('edit-email').value = u.email;
  document.getElementById('edit-account').value = u.accountNumber;
  document.getElementById('edit-balance').value = u.balance;
  document.getElementById('edit-password').value = '';
  document.getElementById('edit-message').classList.remove('show');
  document.getElementById('edit-modal').classList.remove('hidden');
}

function closeEditModal() {
  document.getElementById('edit-modal').classList.add('hidden');
}


function openEditTxnModal(txnId) {
  const txns = window._adminTxns || [];
  const t = txns.find(x => x.id === txnId);
  if (!t) return;
  document.getElementById('edit-txn-id').value = t.id;
  document.getElementById('edit-txn-account').value = (t.userName || '') + ' • ' + t.accountNumber;
  document.getElementById('edit-txn-type').value = t.type;
  document.getElementById('edit-txn-amount').value = t.amount;
  document.getElementById('edit-txn-desc').value = t.description || '';
  document.getElementById('edit-txn-message').classList.remove('show');
  document.getElementById('edit-txn-modal').classList.remove('hidden');
}
function closeEditTxnModal() {
  document.getElementById('edit-txn-modal').classList.add('hidden');
}
window.deleteTransaction = deleteTransaction;
window.openEditModal = openEditModal;
window.closeEditModal = closeEditModal;
window.openEditTxnModal = openEditTxnModal;
window.closeEditTxnModal = closeEditTxnModal;
window.openAdminChat = openAdminChat;
window.sendAdminReply = sendAdminReply;

// ========== EVENTS ==========
document.addEventListener('DOMContentLoaded', () => {
  applyTheme(getSettings().dark);

  // Auth tabs
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      const target = tab.dataset.tab;
      document.getElementById('login-form').classList.toggle('hidden', target !== 'login');
      document.getElementById('register-form').classList.toggle('hidden', target !== 'register');
      document.getElementById('auth-message').classList.remove('show');
    });
  });

  // Content tabs
  document.querySelectorAll('.ctab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.ctab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      const target = tab.dataset.ctab;
      document.getElementById('transactions-panel').classList.toggle('hidden', target !== 'transactions');
      document.getElementById('transfer-panel').classList.toggle('hidden', target !== 'transfer');
      document.getElementById('profile-panel').classList.toggle('hidden', target !== 'profile');
      document.getElementById('admin-panel').classList.toggle('hidden', target !== 'admin');
      if (target === 'admin') refreshAll();
    });
  });

  // Login
  document.getElementById('login-form').addEventListener('submit', async e => {
    e.preventDefault();
    const email = document.getElementById('login-email').value.trim();
    const password = document.getElementById('login-password').value;
    try {
      const data = await api('/api/login', { method: 'POST', body: JSON.stringify({ email, password }) });
      localStorage.setItem('kb_token', data.token);
      currentUser = data.user;
      showApp();
    } catch (err) {
      showMessage('auth-message', err.message, 'error');
    }
  });

  // Register
  document.getElementById('register-form').addEventListener('submit', async e => {
    e.preventDefault();
    const name = document.getElementById('reg-name').value.trim();
    const email = document.getElementById('reg-email').value.trim();
    const password = document.getElementById('reg-password').value;
    try {
      const data = await api('/api/register', { method: 'POST', body: JSON.stringify({ name, email, password }) });
      showMessage('auth-message', 'Account created! No: ' + data.accountNumber + '. You can login now.', 'success');
      document.querySelector('.tab[data-tab="login"]').click();
      document.getElementById('login-email').value = email;
    } catch (err) {
      showMessage('auth-message', err.message, 'error');
    }
  });

  document.getElementById('logout-btn').addEventListener('click', logout);

  document.getElementById('theme-toggle').addEventListener('click', () => {
    const s = getSettings();
    s.dark = !s.dark;
    saveSettings(s);
    applyTheme(s.dark);
  });
  document.getElementById('dark-mode-switch').addEventListener('change', e => {
    const s = getSettings();
    s.dark = e.target.checked;
    saveSettings(s);
    applyTheme(s.dark);
  });

  document.getElementById('currency-select').addEventListener('change', e => {
    const s = getSettings();
    s.currency = e.target.value;
    saveSettings(s);
    if (currentUser) renderBalance(currentUser);
  });
  document.getElementById('pref-currency').addEventListener('change', e => {
    const s = getSettings();
    s.currency = e.target.value;
    saveSettings(s);
    document.getElementById('currency-select').value = e.target.value;
    if (currentUser) renderBalance(currentUser);
  });

  document.getElementById('avatar-upload').addEventListener('change', async e => {
    const file = e.target.files[0];
    if (!file) return;
    if (file.size > 500000) { alert('Image too large (max 500KB)'); return; }
    const reader = new FileReader();
    reader.onload = async ev => {
      try {
        await api('/api/avatar', { method: 'POST', body: JSON.stringify({ avatar: ev.target.result }) });
        currentUser.avatar = ev.target.result;
        updateAvatarDisplay(currentUser);
      } catch (err) { alert(err.message); }
    };
    reader.readAsDataURL(file);
  });

  document.getElementById('refresh-btn').addEventListener('click', () => refreshAll());
  document.getElementById('transfer-btn').addEventListener('click', () => {
    document.querySelector('.ctab[data-ctab="transfer"]').click();
  });

  document.getElementById('transfer-form').addEventListener('submit', async e => {
    e.preventDefault();
    const toAccount = document.getElementById('to-account').value.trim();
    const amount = document.getElementById('transfer-amount').value;
    const desc = document.getElementById('transfer-desc').value.trim();
    try {
      await api('/api/transfer', { method: 'POST', body: JSON.stringify({ toAccount, amount, description: desc }) });
      showMessage('transfer-message', 'Transfer successful!', 'success');
      document.getElementById('transfer-form').reset();
      refreshAll();
    } catch (err) {
      showMessage('transfer-message', err.message, 'error');
    }
  });

  document.getElementById('admin-txn-form').addEventListener('submit', async e => {
    e.preventDefault();
    const accountNumber = document.getElementById('admin-account').value.trim();
    const type = document.getElementById('admin-type').value;
    const amount = document.getElementById('admin-amount').value;
    const desc = document.getElementById('admin-desc').value.trim();
    try {
      const data = await api('/api/admin/transactions', {
        method: 'POST',
        body: JSON.stringify({ accountNumber, type, amount, description: desc })
      });
      showMessage('admin-message', 'Added. New balance: ' + formatMoney(data.newBalance), 'success');
      document.getElementById('admin-txn-form').reset();
      refreshAll();
    } catch (err) {
      showMessage('admin-message', err.message, 'error');
    }
  });

  // Chat
  document.getElementById('chat-toggle').addEventListener('click', async () => {
    const panel = document.getElementById('chat-panel');
    panel.classList.toggle('hidden');
    if (!panel.classList.contains('hidden') && currentUser && currentUser.role !== 'admin') {
      try {
        const chat = await api('/api/chats');
        renderChatMessages(chat);
      } catch {}
    }
  });
  document.getElementById('chat-close').addEventListener('click', () => {
    document.getElementById('chat-panel').classList.add('hidden');
  });
  document.getElementById('chat-form').addEventListener('submit', async e => {
    e.preventDefault();
    const input = document.getElementById('chat-input');
    const text = input.value.trim();
    if (!text) return;
    try {
      const chat = await api('/api/chats/message', { method: 'POST', body: JSON.stringify({ text }) });
      renderChatMessages(chat);
      input.value = '';
      if (currentUser.role === 'admin') refreshAll();
    } catch (err) { alert(err.message); }
  });

  
  // Edit user form
  const editForm = document.getElementById('edit-user-form');
  if (editForm) {
    editForm.addEventListener('submit', async e => {
      e.preventDefault();
      const id = document.getElementById('edit-user-id').value;
      const name = document.getElementById('edit-name').value.trim();
      const email = document.getElementById('edit-email').value.trim();
      const balance = document.getElementById('edit-balance').value;
      const password = document.getElementById('edit-password').value;
      const body = { name, email, balance };
      if (password) body.password = password;
      try {
        await api('/api/admin/users/' + id, { method: 'PUT', body: JSON.stringify(body) });
        showMessage('edit-message', 'Account updated successfully', 'success');
        setTimeout(() => { closeEditModal(); refreshAll(); }, 800);
      } catch (err) {
        showMessage('edit-message', err.message, 'error');
      }
    });
  }


  const editTxnForm = document.getElementById('edit-txn-form');
  if (editTxnForm) {
    editTxnForm.addEventListener('submit', async e => {
      e.preventDefault();
      const id = document.getElementById('edit-txn-id').value;
      const type = document.getElementById('edit-txn-type').value;
      const amount = document.getElementById('edit-txn-amount').value;
      const description = document.getElementById('edit-txn-desc').value.trim();
      try {
        await api('/api/admin/transactions/' + id, {
          method: 'PUT',
          body: JSON.stringify({ type, amount, description })
        });
        showMessage('edit-txn-message', 'Transaction updated', 'success');
        setTimeout(() => { closeEditTxnModal(); refreshAll(); }, 800);
      } catch (err) {
        showMessage('edit-txn-message', err.message, 'error');
      }
    });
  }

// Restore session
  if (localStorage.getItem('kb_token')) {
    api('/api/me').then(user => {
      currentUser = user;
      showApp();
    }).catch(() => logout());
  }
});
