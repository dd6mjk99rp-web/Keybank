# Key Bank - Shared Online Banking

## Run locally
```
npm install
npm start
```
Open http://localhost:3000

Admin: admin@keybank.com / Admin@123

## Deploy to Render.com (free)
1. Create account at render.com
2. New > Web Service
3. Connect this repo or upload
4. Build: npm install
5. Start: npm start
6. Add disk for /data if you want persistence across restarts
